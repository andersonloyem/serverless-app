# serverless-app

cmd :
# install serverless

npm install -g serverless





1. faire  : npm i -g serverless && serverless init sf_GnCwl9hM 
pour installer serverless et initialiser le compte serverless.com dans le PC

2. faire cd app-serverless && serverless deploy
recuperer les configs du projets
