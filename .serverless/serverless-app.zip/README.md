# serverless-app

cmd :
# install serverless

npm install -g serverless





1. faire  : npm i -g serverless && serverless init sf_GnCwl9hM 
pour installer serverless et initialiser le compte serverless.com dans le PC

2. faire cd app-serverless && serverless deploy
recuperer les configs du projets


!ref :
 - https://gist.github.com/maxkostinevich/9672966565aeb749d41e49673be4e7fa
 - https://faun.pub/aws-lambda-serverless-framework-python-part-1-a-step-by-step-hello-world-4182202aba4a
 - https://techinjektion.com/api-aws-lambda-python-dynamodb/ 